package com.demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OrderApplicationTest {

    @Test
    void contextLoads() {
        // This test will fail if the Spring application context can't start
    }
}
