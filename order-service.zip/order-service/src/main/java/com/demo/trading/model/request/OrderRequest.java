package com.demo.trading.model.request;

import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;

public record OrderRequest(
        @NotBlank(message = "Product is required")
        String product,

        @Min(value = 1, message = "Quantity must be greater than 0")
        int quantity,

        @DecimalMin(value = "0.0", inclusive = true, message = "Price cannot be negative")
        double price,

        @NotBlank(message = "Trading symbol is required")
        String tradingsymbol,

        @Pattern(regexp = "NSE|BSE|NFO", message = "Exchange must be NSE, BSE, or NFO")
        String exchange,

        @Pattern(regexp = "DAY|IOC", message = "Validity must be DAY or IOC")
        String validity,

        @Pattern(regexp = "BUY|SELL", message = "Transaction type must be BUY or SELL")
        String transaction_type,

        @Pattern(regexp = "MARKET|LIMIT", message = "Order type must be MARKET or LIMIT")
        String order_type
) {}
